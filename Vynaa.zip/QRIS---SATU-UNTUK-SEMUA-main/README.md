![qris](https://github.com/user-attachments/assets/1d47cc4b-d1ba-4603-b09c-2debc2397537)
<img
        src="https://readme-typing-svg.herokuapp.com?font=ShadowsIntoLightsize=50&duration=5500&color=f70787&background=FF673200&center=true&vCenter=true&lines=SCAN+QRIS+UNTUK+MEMBAYAR😊"
            alt="Typing SVG"
        />
    </a>
</p>
</div>
